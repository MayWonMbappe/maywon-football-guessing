# Netlify 部署说明

请直接把 `football-netlify-root.zip` 拖入 Netlify 的手动部署区域。

压缩包根目录已经直接包含：

- `index.html`
- `_redirects`
- `netlify.toml`
- `app.js`
- `football-data.js`
- `styles.css`
- `assets/`

不要把压缩包再放进另一层文件夹后重新压缩。部署完成后，在 Netlify 的 Deploy File Browser 中确认根目录能直接看到 `index.html` 和 `_redirects`。

本网站是纯静态单页网站，不需要构建命令。`_redirects` 内容为：

```text
/* /index.html 200
```

本版本已补充利物浦、法兰克福和朗斯完整一线队名单，并为英超全部球队及指定欧洲强队的 1200 名球员补齐中文译名。更新日期：2026-06-18。
